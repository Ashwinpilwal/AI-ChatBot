import os
import google.generativeai as genai
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS # Import CORS
from dotenv import load_dotenv
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__, static_folder='../frontend', static_url_path='')
CORS(app) # Enable CORS for all routes

# Configure the Gemini API
api_key = os.getenv("GEMINI_API_KEY")
if not api_key:
    logging.error("Error: GEMINI_API_KEY not found in environment variables.")
    # You might want to exit or handle this more gracefully in production
else:
    try:
        genai.configure(api_key=api_key)
        # Test connection (optional but recommended)
        # for model in genai.list_models():
        #     logging.info(f"Found model: {model.name}")
        logging.info("Gemini API configured successfully.")
    except Exception as e:
        logging.error(f"Error configuring Gemini API: {e}")
        # Handle configuration error

# --- Gemini Model Initialization ---
# Choose a model appropriate for text generation/analysis
# Check available models, 'gemini-pro' is a common choice
# Reference: https://ai.google.dev/models/gemini
try:
    model = genai.GenerativeModel('gemini-1.5-flash') # Or 'gemini-pro'
    logging.info(f"Using Gemini model: {model.model_name}")
except Exception as e:
    logging.error(f"Error initializing Gemini model: {e}")
    model = None # Ensure model is None if initialization fails

# --- Helper Function for Gemini Interaction ---
def generate_gemini_response(prompt_text):
    if not model:
        return "Error: Gemini model not initialized."
    if not api_key:
        return "Error: API Key not configured."

    try:
        response = model.generate_content(prompt_text)
        # Handle potential safety blocks or empty responses
        if not response.parts:
             if response.prompt_feedback.block_reason:
                 logging.warning(f"Gemini response blocked. Reason: {response.prompt_feedback.block_reason}")
                 return f"Content blocked due to safety settings: {response.prompt_feedback.block_reason.name}"
             else:
                 logging.warning("Gemini returned no content.")
                 return "Error: Received no content from the AI. The request might have been filtered or the model couldn't generate a response."

        return response.text
    except Exception as e:
        logging.error(f"Error generating content with Gemini: {e}")
        # Provide more specific error info if possible
        if "API key not valid" in str(e):
             return "Error: Invalid Gemini API Key."
        return f"Error interacting with the AI model: {e}"

# --- Scope Checking Function ---
def is_request_in_scope(user_input):
    """
    Uses Gemini to quickly check if the input is related to legal document analysis.
    """
    # Basic check: very short input is likely out of scope
    if len(user_input.split()) < 15: # Arbitrary threshold
        logging.info("Input too short, likely out of scope.")
        return False, "Input seems too short to be a legal document or a request about one."

    # Use AI for a more robust check
    scope_check_prompt = f"""
    Analyze the following text. Is it likely a legal document (like a contract, agreement, lease, terms of service, privacy policy, etc.) OR a direct request to summarize or analyze such a document?
    Respond ONLY with 'YES' or 'NO'. Do not add any explanation.

    Text:
    \"\"\"
    {user_input[:1000]}
    \"\"\"

    Your response (YES or NO):""" # Limit input length for scope check efficiency

    logging.info("Performing AI scope check...")
    scope_response = generate_gemini_response(scope_check_prompt).strip().upper()
    logging.info(f"Scope check response: {scope_response}")

    if "YES" in scope_response:
        return True, ""
    else:
        # Optionally, check common legal keywords as a fallback (less reliable)
        keywords = ['agreement', 'contract', 'clause', 'party', 'parties', 'whereas', 'heretofore', 'terms', 'conditions', 'policy', 'lease']
        if any(keyword in user_input.lower() for keyword in keywords):
             logging.warning("AI scope check was 'NO', but keywords found. Proceeding cautiously.")
             # return True, "" # Uncomment if you want keywords to override AI 'NO'
             return False, "The text doesn't seem to be a legal document or a request to analyze one." # Sticking with AI check
        else:
            logging.info("AI scope check 'NO' and no common keywords found.")
            return False, "The text doesn't appear to be a legal document or a request to analyze one."


# --- API Endpoint ---
@app.route('/analyze', methods=['POST'])
def analyze_document():
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    data = request.get_json()
    user_input = data.get('text', None)

    if not user_input:
        return jsonify({"error": "No text provided"}), 400

    logging.info(f"Received text for analysis (length: {len(user_input)})")

    # 1. Check Scope
    in_scope, scope_reason = is_request_in_scope(user_input)

    if not in_scope:
        logging.info("Request determined to be out of scope.")
        # Use the reason from the scope check if available, otherwise a generic message
        out_of_scope_message = scope_reason or "I specialize in summarizing legal documents. This request seems outside that scope."
        return jsonify({"response": out_of_scope_message})

    # 2. If In Scope, Summarize
    logging.info("Request is in scope. Proceeding with summarization.")
    summarization_prompt = f"""
    You are an AI Legal Document Analyzer. Your task is to provide a concise summary of the key aspects of the following legal text.
    Focus on:
    1.  **Purpose:** What is the main goal of this document?
    2.  **Parties:** Identify the main parties involved (if clearly stated).
    3.  **Key Obligations/Rights:** Briefly list the most important duties or entitlements for the main parties.
    4.  **Duration/Term:** Mention the length of the agreement or key dates if specified.
    5.  **Governing Law/Jurisdiction:** Note if a specific law or location for disputes is mentioned.

    Provide the summary in clear, simple language. Avoid legal jargon where possible, but be accurate. Do not add opinions or advice. Start the summary directly.

    Legal Text to Summarize:
    \"\"\"
    {user_input}
    \"\"\"

    Concise Summary:
    """

    summary = generate_gemini_response(summarization_prompt)

    # Basic check if the summary is meaningful or an error/generic response
    if summary.startswith("Error:") or "Content blocked" in summary or len(summary) < 50 : # Add checks for other potential non-summary responses
         logging.warning(f"Received potentially problematic summary: {summary}")
         # Potentially refine this - maybe the doc WAS legal but Gemini failed.
         # For now, return the Gemini output, which might contain the error.
         # Or, return a generic failure message:
         # return jsonify({"response": "Sorry, I encountered an issue trying to summarize the document."})
         return jsonify({"response": summary}) # Return the actual response/error from Gemini

    logging.info("Summary generated successfully.")
    return jsonify({"response": summary})

# --- Serve Frontend ---
@app.route('/')
def serve_index():
    # Serves files from the 'static_folder' which is set to '../frontend'
    return send_from_directory(app.static_folder, 'index.html')

# This route is needed if your static files (CSS, JS) are NOT in the root of static_folder
# Since style.css and script.js are in the root of '../frontend', this might not be strictly
# necessary with the current Flask setup, but it's explicit.
@app.route('/<path:path>')
def serve_static_files(path):
    return send_from_directory(app.static_folder, path)


if __name__ == '__main__':
    # Use 0.0.0.0 to make it accessible on your network
    # Use debug=True only for development, False for production
    app.run(host='0.0.0.0', port=5001, debug=True)