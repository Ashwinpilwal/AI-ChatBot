document.addEventListener('DOMContentLoaded', () => {
    const analyzeButton = document.getElementById('analyze-button');
    const legalTextInput = document.getElementById('legal-text');
    const chatHistory = document.getElementById('chat-history');
    const loadingIndicator = document.getElementById('loading-indicator');

    // Backend API endpoint URL
    const backendUrl = 'http://127.0.0.1:5001/analyze'; // Adjust if needed

    // --- Function to add messages to chat history ---
    function addMessageToChat(sender, messageContent) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message');

        const contentDiv = document.createElement('div');
        contentDiv.classList.add('message-content');

        if (sender === 'user') {
            messageDiv.classList.add('user-message');
            // Simple text display for user input
            contentDiv.textContent = messageContent;
        } else { // AI or Error
            messageDiv.classList.add('ai-response');
             // Display AI response (might contain line breaks)
             // Use textContent for safety against HTML injection
             contentDiv.textContent = messageContent;
        }

        messageDiv.appendChild(contentDiv);
        chatHistory.appendChild(messageDiv); 

        // Scroll to the bottom of the chat history
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }

    // --- Send message handler ---
    async function sendMessage() {
        const textToAnalyze = legalTextInput.value.trim();

        if (!textToAnalyze) {
            // Maybe add a temporary error message or just ignore empty sends
            return;
        }

        // 1. Add user message to chat
        addMessageToChat('user', textToAnalyze);

        // 2. Clear input and disable button/show loading
        legalTextInput.value = '';
        legalTextInput.style.height = 'auto'; 
        legalTextInput.focus(); // Keep focus on input
        analyzeButton.disabled = true;
        loadingIndicator.style.display = 'flex'; 

        try {
            console.log("Sending text to backend:", textToAnalyze.substring(0, 100) + "...");

            const response = await fetch(backendUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ text: textToAnalyze }),
            });

            console.log("Received response status:", response.status);
            console.log("Received response status:", response.ok);

            let responseData; 
            if (!response.ok) {
                let errorMsg = `HTTP error! Status: ${response.status}`;
                 try {
                     const errorData = await response.json();
                     // error from backend json if available
                     responseData = errorData.error || JSON.stringify(errorData);
                 } catch (e) {
                    // Fallback if response is not JSON
                    console.log("Error me bhi erroe aa gaya!!")
                    responseData = `${errorMsg} - ${response.statusText || 'Server error'}`;
                 }
                 addMessageToChat('ai', `Error: ${responseData}`);

            } else {
                 responseData = await response.json();
                 console.log("Received data from backend:", responseData);
                 if (responseData.response) {
                    // 3. Add AI response to chat
                    addMessageToChat('ai', responseData.response);
                 } 
                //  
                // 
            }
        } catch (error) {
            console.error('Error during fetch:', error);
            addMessageToChat('ai', `Network or fetch error: ${error.message}. Please ensure the backend is running.`);
        } finally {
            analyzeButton.disabled = false;
            loadingIndicator.style.display = 'none';
            legalTextInput.focus();
        }
    }

    // --- Event Listeners ---
    analyzeButton.addEventListener('click', sendMessage);

    // Send message on Enter key press in textarea (Shift+Enter for newline)
    legalTextInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault(); // Prevent default newline on Enter
            sendMessage();
        }
    });

}); 






// For Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    sidebar.classList.toggle("active");
    const logo = document.querySelector(".logo");
    logo.classList.toggle("shifted");
    // const chatContainer = document.querySelector(".chat-container")
    // chatContainer.classList.toggle("shiftAgain")
    // const chatInput = document.querySelector(".chat-input-area")
    // chatInput.classList.toggle("shiftAgainAgain")
  }

// For copy paste  

function copyText() {
    const text = document.getElementById("dummy-text").innerText;
    navigator.clipboard.writeText(text).then(() => {
      alert("Copied to clipboard!");
    });
  }




//   Dark Theme Changer


const themeIcon = document.getElementById("theme-icon");

themeIcon.onclick = function () {
  document.body.classList.toggle("dark-mode");
  document.querySelector(".chat-history").classList.toggle("chat-history-dark");
  document.querySelector("#sidebar").classList.toggle("sidebar-dark");
  
  //   document.querySelector(".sample-text").classList.toggle("sample-text-dark");   ---> for multiple elements you need below approach
  document.querySelectorAll(".sample-text").forEach(function (el) {
      el.classList.toggle("sample-text-dark");
    });

  document.querySelector(".navigation-bar").classList.toggle("navigation-bar-dark");
  document.querySelector(".ai-response").classList.toggle("ai-response-dark");
    


  // Switch icon based on current theme
  if (document.body.classList.contains("dark-mode")) {
    themeIcon.src = "img/sun.png";
  } else {
    themeIcon.src = "img/moon.png";
  }
};
